from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,username,password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://localhost:55297')
        #self.client = MongoClient('mongodb://%s:%s@localhost:55297' % ("Accuser", password))
        self.database = self.client['AAC']
       
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary            
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    
    def read_all(self,data):
            cursor = self.database.animals.find(data,{"_id":False})  # data should be dictionary   
            return cursor
        
    def read(self,data):
        return self.database.animals.find_one(data)
     
    def update(self, _keys,_data):
        if _data is not None and _keys is not None:
            self.database.animals.update_many(_keys,{'$set':_data})  # _keys will check for the doc to update 
            data = self.read(_data)
            return data
        else:
            raise Exception("please nter both key and data to modify the collection")


    def delete(self, _data):
        if _data is not None:
            data = self.read(_data) # checj if animal exists
            if data is None:
                print("Animal not found")
                return
            #if found delete the animal or animals
            self.database.animals.delete_many(_data)  # data should be dictionary 
            data = self.read(_data) #confirm if animal was deleted
            return data
        else:
            raise Exception("nothing to read, hint is empty")
